/****************************/
/* TABELLA CONVERSIONE DATE */
/****************************/

/* cfr. istruzioni nello script MK1DATECNV.SQL */

set path = MK1DATECNV, SYSTEM PATH;

-- esecuzione caricamento iniziale della tabella (1 sola volta)
CALL LOAD_DATE_CONVERSION_TABLE;
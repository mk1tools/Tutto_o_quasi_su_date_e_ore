/****************************/
/* TABELLA CONVERSIONE DATE */
/****************************/

-- libreria originale: QWQCENT
-- tabella originale: DATE_CONV
-- fonte originale: IBM DB2 Web Query redbook "Getting started with DB2 Web Query for i" (appendix B p. 542-552)
-- revisione: MK1 MarkOneTools, Marco Riva, (c) 2011-2019, www.markonetools.it
-- versione: 2.0

/*--- End User License Agreement ---
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.

  THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS "AS IS" AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/

/*--- ISTRUZIONI DI USO ---
1) Copiare gli script SQL MK1DATECNV.SQL, MK1DATECNV_LOAD.SQL, MK1DATECNV_UPDATE.SQL in una cartella di IFS (p.es. /home)
2) Eseguire da riga comandi lo script di installazione
RUNSQLSTM SRCSTMF('/home/MK1DATECNV.SQL') COMMIT(*NONE) NAMING(*SYS) ERRLVL(20) DATFMT(*ISO) DATSEP(-)
3) Al termine troverete la libreria MK1DATECNV con:
	- tabella Date_Conversion (DATECNV): tabella di conversione date
	- procedura LOAD_DATE_CONVERSION_TABLE (LODDATCNV) per il caricamento iniziale della tabella di conversione date
	- procedura UPDATE_DATE_CONVERSION_TABLE (UPDDATCNV) per aggiornare i campi DC_CURRENT* della tabella di conversione date
	- area dati MK1VER con le informazioni sulla versione installata
4) Eseguire una tantum lo script SQL MK1DATECNV_LOAD.SQL per popolare la tabella di conversione date
RUNSQLSTM SRCSTMF('/home/MK1DATECNV_LOAD.SQL') DFTRDBCOL(MK1DATCNV) COMMIT(*NONE) NAMING(*SYS) ERRLVL(20) DATFMT(*ISO) DATSEP(-)
  Al termine la tabella sar� popolata con i record della date comprese tra 1/1/1900 e 31/12/2099
5) Se si desidera mantenere aggiornati i campi DC_CURRENT* della tabella di conversione date occorre schedulare giornalmente l'esecuzione dello script MK1DATECNV_UPDATE.SQL
ADDJOBSCDE JOB(DATECNVUPD) CMD(RUNSQLSTM SRCSTMF('/home/MK1DATECNV_UPDATE.SQL') DFTRDBCOL(MK1DATCNV) COMMIT(*NONE) NAMING(*SYS) ERRLVL(20) DATFMT(*ISO) DATSEP(-)) FRQ(*WEEKLY) SCDDATE(*NONE) SCDDAY(*ALL) SCDTIME(000100) TEXT('Tabella conversione date - aggiornamento')
*/

/*--- [1] creazione libreria ---*/
drop schema MK1_Date_Conversion cascade;

create schema MK1_Date_Conversion for MK1DATECNV;

call qcmdexc('CHGCURLIB MK1DATECNV');
call qcmdexc('CHGJRN JRN(*CURLIB/QSQJRN) DLTRCV(*YES)');
call qcmdexc('CHGOBJD OBJ(MK1DATECNV) OBJTYPE(*LIB) text(''MK1 Tabella conversione date 2.0'')');

set current schema = 'MK1DATECNV';

/*--- [2] creazione tabella ---*/
        -- la tabella originale IBM ha il ccsid 37
create or replace table Date_Conversion for system name DATECNV
  (
   DC_DATE date,
   DC_JDE_JULIAN_DATE for column DC_JDE_JUL decimal(6, 0),
   DC_MDYY_DEC for column DC_MDYY_P decimal(8, 0),
   DC_MDYY_ZONED for column DC_MDYY_Z numeric(8, 0),
   DC_MDYY_CHAR for column DC_MDYY_C char(8),
   DC_YYMD_DEC for column DC_YYMD_P decimal(8, 0),
   DC_YYMD_ZONED for column DC_YYMD_Z numeric(8, 0),
   DC_YYMD_CHAR for column DC_YYMD_C char(8),
   DC_CC_CHAR char(2),
   DC_YY_CHAR char(2),
   DC_MM_CHAR char(2),
   DC_DD_CHAR char(2),
   DC_YEAR integer,
   DC_DOW integer,
   DC_DOY integer,
   DC_WOY integer,
   DC_QOY integer,
   DC_CC numeric(2, 0),
   DC_YY numeric(2, 0),
   DC_YYYY numeric(4, 0),
   DC_MM numeric(2, 0),
   DC_DD numeric(2, 0),
   DC_DAY_NAME for column DC_DAY_NAM char(9),
   DC_QUARTER_NAME for column DC_QTR_NAM char(6),
   DC_WEEKEND char(1),
   -- DC_SEASON char(6),
   DC_SEASON char(9),
   DC_FISCAL_YEAR for column DC_FIS_YR integer,
   DC_FISCAL_QUARTER for column DC_FIS_QTR integer,
   DC_MONTH_NAME for column DC_MO_NM char(9),
   DC_MONTH_ABRV for column DC_MO_ABV char(3),
   DC_JULIAN numeric(7, 0),
   DC_CYYMMDD decimal(7, 0),
   DC_EXCEL_DATE for column DC_EXCEL integer,
   DC_WEEK_STARTING_DATE for column DC_WKSTR DATE,
   DC_WEEK_ENDING_DATE for column DC_WKEND DATE,
   DC_WEEK_ENDING_SUN_DATE for column DC_WKENDS DATE, -- no IBM
   DC_SAME_DAY_LAST_YEAR for column DC_SDLY DATE,

   DC_CURRENT_DAY for column DC_CDAY char(1),
   DC_CURRENT_WEEK for column DC_CWEEK char(1),
   DC_CURRENT_MONTH for column DC_CMONTH char(1),
   DC_CURRENT_QUARTER for column DC_CQTR char(1),
   DC_CURRENT_YEAR for column DC_CYEAR char(1),
   DC_CURRENT_DAY_LAST_YEAR for column DC_LDAY char(1),
   DC_CURRENT_WEEK_LAST_YEAR for column DC_LWEEK char(1),
   DC_CURRENT_MONTH_LAST_YEAR for column DC_LMONTH char(1),
   DC_CURRENT_QUARTER_LAST_YEAR for column DC_LQTR char(1),
   DC_CURRENT_YEAR_LAST_YEAR for column DC_LYEAR char(1)
  )
 keep in memory yes
 on replace delete rows;

label on table Date_Conversion is 'Tabella conversione date 2.0';
comment on table Date_Conversion is 'Tabella conversione date 2.0';

label on column Date_Conversion
  (
   DC_DATE text is 'Date (date format)',
   DC_JDE_JULIAN_DATE text is 'JDE Julian Date (CYYDDD decimal)',
   DC_MDYY_DEC text is 'Date (MMDDYYYY packed decimal)',
   DC_MDYY_ZONED text is 'Date (MMDDYYYY zoned decimal)' ,
   DC_MDYY_CHAR text is 'Date (MMDDYYYY character)' ,
   DC_YYMD_DEC text is 'Date (YYYYMMDD packed decimal)' ,
   DC_YYMD_ZONED text is 'Date (YYYYMMDD zoned decimal)' ,
   DC_YYMD_CHAR text is 'Date (YYYYMMDD character)' ,
   DC_CC_CHAR text is 'Century (2 characters)' ,
   DC_YY_CHAR text is 'Year (2 characters)' ,
   DC_MM_CHAR text is 'Month (2 characters)' ,
   DC_DD_CHAR text is 'Day (2 characters)' ,
   DC_YEAR text is 'Year (4 digits)' ,
   DC_DOW text is 'Day of week (1-7)' ,
   DC_DOY text is 'Day of year (1-366)' ,
   DC_WOY text is 'Week of year (1-52)' ,
   DC_QOY text is 'Quarter of year (1-4)' ,
   DC_CC text is 'Century (2 digits)' ,
   DC_YY text is 'Year (2 digits)' ,
   DC_YYYY text is 'Year (4 digits)' ,
   DC_MM text is 'Month (2 digits)' ,
   DC_DD text is 'Day (2 digits)' ,
   DC_DAY_NAME text is 'Day Name (Monday,etc.)' ,
   DC_QUARTER_NAME text is 'Quarter name (2008Q1)' ,
   DC_WEEKEND text is 'Weekend Flag (S or N)' ,
   DC_SEASON text is 'Season (Spring, Summer, Autumn, Winter)' ,
   DC_FISCAL_YEAR text is 'Fiscal year (4 digits) from April' ,
   DC_FISCAL_QUARTER text is 'Fiscal quarter (1-4) from April' ,
   DC_MONTH_NAME text is 'Month name (January, etc)' ,
   DC_MONTH_ABRV text is 'Month abbreviation (Jan, Feb, etc)' ,
   DC_JULIAN text is 'Date in Julian format' ,
   DC_CYYMMDD text is 'CYYMMDD packed C = 0 for 1900 & C = 1 for 2000' ,
   DC_EXCEL_DATE text is 'Date in Excel format' ,
   -- DC_WEEK_STARTING_DATE text is 'Week starting date (the prior Saturday)',
   DC_WEEK_STARTING_DATE text is 'Week starting date (the prior Monday)',
   DC_WEEK_ENDING_DATE text is 'Week ending date (the next Friday)',
   DC_WEEK_ENDING_SUN_DATE text is 'Week ending date (the next Sunday)', -- no IBM
   DC_SAME_DAY_LAST_YEAR text is 'Same day last year',

   DC_CURRENT_DAY text is 'Current Day (S/N)',
   DC_CURRENT_WEEK text is 'Current Week (S/N)',
   DC_CURRENT_MONTH text is 'Current Month (S/N)',
   DC_CURRENT_QUARTER text is 'Current Quarter (S/N)',
   DC_CURRENT_YEAR text is 'Current Year (S/N)',
   DC_CURRENT_DAY_LAST_YEAR text is 'Current Day Last Year (S/N)',
   DC_CURRENT_WEEK_LAST_YEAR text is 'Current Week Last Year (S/N)',
   DC_CURRENT_MONTH_LAST_YEAR text is 'Current Month Last Year (S/N)',
   DC_CURRENT_QUARTER_LAST_YEAR text is 'Current Quarter Last Year (S/N)',
   DC_CURRENT_YEAR_LAST_YEAR text is 'Current Year Last Year (S/N)'
 );

label on column Date_Conversion
  (
   DC_DATE is 'Date (date format)',
   DC_JDE_JULIAN_DATE is 'JDE Julian Date (CYYDDD decimal)',
   DC_MDYY_DEC is 'Date (MMDDYYYY packed decimal)',
   DC_MDYY_ZONED is 'Date (MMDDYYYY zoned decimal)' ,
   DC_MDYY_CHAR is 'Date (MMDDYYYY character)' ,
   DC_YYMD_DEC is 'Date (YYYYMMDD packed decimal)' ,
   DC_YYMD_ZONED is 'Date (YYYYMMDD zoned decimal)' ,
   DC_YYMD_CHAR is 'Date (YYYYMMDD character)' ,
   DC_CC_CHAR is 'Century (2 characters)' ,
   DC_YY_CHAR is 'Year (2 characters)' ,
   DC_MM_CHAR is 'Month (2 characters)' ,
   DC_DD_CHAR is 'Day (2 characters)' ,
   DC_YEAR is 'Year (4 digits)' ,
   DC_DOW is 'Day of week (1-7)' ,
   DC_DOY is 'Day of year (1-366)' ,
   DC_WOY is 'Week of year (1-52)' ,
   DC_QOY is 'Quarter of year (1-4)' ,
   DC_CC is 'Century (2 digits)' ,
   DC_YY is 'Year (2 digits)' ,
   DC_YYYY is 'Year (4 digits)' ,
   DC_MM is 'Month (2 digits)' ,
   DC_DD is 'Day (2 digits)' ,
   DC_DAY_NAME is 'Day Name (Monday,etc.)' ,
   DC_QUARTER_NAME is 'Quarter name (2008Q1)' ,
   DC_WEEKEND is 'Weekend Flag (S or N)' ,
   DC_SEASON is 'Season (Spring, Summer, Autumn, Winter)' ,
   DC_FISCAL_YEAR is 'Ftext iscal year (4 digits) from April' ,
   DC_FISCAL_QUARTER is 'Ftext iscal quarter (1-4) from April' ,
   DC_MONTH_NAME is 'Month name (January, etc)' ,
   DC_MONTH_ABRV is 'Month abbreviation (Jan, Feb, etc)' ,
   DC_JULIAN is 'Date in Julian format' ,
   DC_CYYMMDD is 'CYYMMDD packed C = 0 for 1900 & C = 1 for 2000' ,
   DC_EXCEL_DATE is 'Date in Excel format' ,
   -- DC_WEEK_STARTING_DATE is 'Week starting date (the prior Saturday)',
   DC_WEEK_STARTING_DATE is 'Week starting date (the prior Monday)',
   DC_WEEK_ENDING_DATE is 'Week ending date (the next Friday)',
   DC_WEEK_ENDING_SUN_DATE is 'Week ending date (the next Sunday)', -- no IBM
   DC_SAME_DAY_LAST_YEAR is 'Same day last year',

   DC_CURRENT_DAY is 'Current Day (S/N)',
   DC_CURRENT_WEEK is 'Current Week (S/N)',
   DC_CURRENT_MONTH is 'Current Month (S/N)',
   DC_CURRENT_QUARTER is 'Current Quarter (S/N)',
   DC_CURRENT_YEAR is 'Current Year (S/N)',
   DC_CURRENT_DAY_LAST_YEAR is 'Current Day Last Year (S/N)',
   DC_CURRENT_WEEK_LAST_YEAR is 'Current Week Last Year (S/N)',
   DC_CURRENT_MONTH_LAST_YEAR is 'Current Month Last Year (S/N)',
   DC_CURRENT_QUARTER_LAST_YEAR is 'Current Quarter Last Year (S/N)',
   DC_CURRENT_YEAR_LAST_YEAR is 'Current Year Last Year (S/N)'
 );

-- indici sui tipici campi date legacy per ottimizzazione performance
create index Date_Conversion_01I for system name DATECNV01I on Date_Conversion (DC_YYMD_DEC);
label on index Date_Conversion_01I is 'RI per data YYMD packed';

create index Date_Conversion_02I for system name DATECNV02I on Date_Conversion (DC_YYMD_ZONED);
label on index Date_Conversion_02I is 'RI per data YYMD zoned';

create index Date_Conversion_03I for system name DATECNV03I on Date_Conversion (DC_YYYY, DC_MM, DC_DD);
label on index Date_Conversion_03I is 'RI per data su campi separati numerici';

-- eventualmente creare altri indici in base alle proprie esigenze

/*--- [3] creazione procedure ---*/

-- procedura popolazione iniziale della tabella
create or replace procedure LOAD_DATE_CONVERSION_TABLE( )
  language sql
  specific LODDATCNV

 BEGIN
    -- dichiarazioni
    declare VAR_DATE date;
    declare VAR_JDE_JULIAN_DATE decimal(6, 0);
    declare VAR_JDE_JULIAN_DATE_CHAR char(6);
    declare VAR_DATE_MDYY_DEC decimal(8, 0);
    declare VAR_DATE_MDYY_ZONED numeric(8, 0);
    declare VAR_DATE_MDYY_CHAR char(8);
    declare VAR_DATE_YYMD_DEC decimal(8, 0);
    declare VAR_DATE_YYMD_ZONED numeric(8, 0);
    declare VAR_DATE_YYMD_CHAR char(8);
    declare VAR_CC_CHAR char(2);
    declare VAR_YY_CHAR char(2);
    declare VAR_MM_CHAR char(2);
    declare VAR_DD_CHAR char(2);
    declare VAR_YEAR integer;
    declare VAR_DOW integer;
    declare VAR_DOY integer;
    declare VAR_WOY integer;
    declare VAR_QOY integer;
    declare VAR_CC numeric(2, 0);
    declare VAR_YY numeric(2, 0);
    declare VAR_YYYY numeric(4, 0);
    declare VAR_MM numeric(2, 0);
    declare VAR_DD numeric(2, 0);
    declare VAR_DAY_NAME char(9);
    declare VAR_QUARTER_NAME char(6);
    declare VAR_WEEKEND char(1);
    -- declare VAR_SEASON char(6);
    declare VAR_SEASON char(9);
    declare VAR_FISCAL_YEAR integer;
    declare VAR_FISCAL_QUARTER integer;
    declare VAR_MONTH_NAME char(9);
    declare VAR_MONTH_ABRV char(3);
    declare VAR_JULIAN numeric(7, 0);
    declare VAR_EXCEL_DATE integer;
    declare VAR_CYYMMDD_DEC decimal(7, 0);
    declare VAR_WEEK_ENDING_DATE DATE;
    declare VAR_WEEK_ENDING_SUN_DATE DATE;
    declare VAR_WEEK_STARTING_DATE DATE;
    declare VAR_SAME_DAY_LAST_YEAR DATE;
    declare VAR_CURRENT_DAY char(1);
    declare VAR_CURRENT_WEEK char(1);
    declare VAR_CURRENT_MONTH char(1);
    declare VAR_CURRENT_QUARTER char(1);
    declare VAR_CURRENT_YEAR char(1);
    declare VAR_CURRENT_DAY_LAST_YEAR char(1);
    declare VAR_CURRENT_WEEK_LAST_YEAR char(1);
    declare VAR_CURRENT_MONTH_LAST_YEAR char(1);
    declare VAR_CURRENT_QUARTER_LAST_YEAR char(1);
    declare VAR_CURRENT_YEAR_LAST_YEAR char(1);
    -- impostazioni iniziali
    set VAR_DATE = '01/01/1900';  -- DATA INIZIO
    set VAR_CURRENT_DAY = 'N';
    set VAR_CURRENT_WEEK = 'N';
    set VAR_CURRENT_MONTH = 'N';
    set VAR_CURRENT_QUARTER = 'N';
    set VAR_CURRENT_YEAR = 'N';
    set VAR_CURRENT_DAY_LAST_YEAR = 'N';
    set VAR_CURRENT_WEEK_LAST_YEAR = 'N';
    set VAR_CURRENT_MONTH_LAST_YEAR = 'N';
    set VAR_CURRENT_QUARTER_LAST_YEAR = 'N';
    set VAR_CURRENT_YEAR_LAST_YEAR = 'N';

    -- pulizia tabella date
    truncate Date_Conversion immediate;

    -- ciclo su date da 01/01/1900 a 31/12/2099
    repeat
      set VAR_YEAR = year(VAR_DATE) ;
      set VAR_EXCEL_DATE = int(days(VAR_DATE) - days(date('01/01/1900'))) + 1 ;
      -- Excel incorrectly calculates Feb 29, 1900 as a leap day (when in fact it is not).
      -- The following accounts for that.
      set VAR_EXCEL_DATE =
      	(case
      	   when VAR_EXCEL_DATE > 59
      	     then VAR_EXCEL_DATE + 1
      	     else VAR_EXCEL_DATE
      	 end) ;
      set VAR_JDE_JULIAN_DATE = (int(var_date - date('01/01/1900'))/10000)*1000	+ dayofyear(VAR_DATE);
      set VAR_DOW = dayofweek_iso(VAR_DATE);
      set VAR_DOY = dayofyear(VAR_DATE);
      -- set VAR_WOY = WEEK ( VAR_DATE ) ;
      set VAR_WOY = week_iso(VAR_DATE);
      set VAR_QOY = quarter(VAR_DATE);
      set VAR_CC_CHAR = substring(char(year(VAR_DATE)), 1, 2);
      set VAR_YY_CHAR = substring(char(year(VAR_DATE)), 3, 2);
      set VAR_MM_CHAR = substring(digits(month(VAR_DATE)), 9, 2);
      set VAR_DD_CHAR = substring(digits(day(VAR_DATE)), 9, 2);
      set VAR_CC = decimal(substring(char(year(VAR_DATE)), 1, 2));
      set VAR_YY = decimal(substring(char (year(VAR_DATE)), 3, 2));
      set VAR_YYYY = decimal(substring(char(year(VAR_DATE)), 1, 4));
      set VAR_MM = month(VAR_DATE);
      set VAR_DD = day(VAR_DATE);
      set VAR_DATE_MDYY_CHAR = VAR_MM_CHAR concat VAR_DD_CHAR concat VAR_CC_CHAR concat VAR_YY_CHAR;
      set VAR_DATE_MDYY_DEC = decimal(VAR_DATE_MDYY_CHAR);
      set VAR_DATE_MDYY_ZONED = VAR_DATE_MDYY_DEC;
      set VAR_DATE_YYMD_CHAR = (VAR_CC * 1000000) + (VAR_YY * 10000) + (VAR_MM * 100) + VAR_DD;
      set VAR_DATE_YYMD_DEC = decimal (VAR_DATE_YYMD_CHAR);
      set VAR_DATE_YYMD_ZONED = VAR_DATE_YYMD_DEC;
      set VAR_CYYMMDD_DEC =
      	(case
      	   when VAR_CC = 19
             then (VAR_YY * 10000) + (VAR_MM * 100) + VAR_DD
             else 1000000 + (VAR_YY * 10000) + (VAR_MM * 100) + VAR_DD
      	 end);
      --set VAR_DAY_NAME =
      --	( CASE VAR_DOW
      --		WHEN 1
      --		-- THEN 'Monday'
      --		THEN 'Lunedì'
      --		WHEN 2
      --		-- THEN 'Tuesday'
      --		THEN 'Martedì'
      --		WHEN 3
      --		-- THEN 'Wednesday'
      --		THEN 'Mercoledì'
      --		WHEN 4
      --		-- THEN 'Thursday'
      --		THEN 'Giovedì'
      --		WHEN 5
      --		-- THEN 'Friday'
      --		THEN 'Venerdì'
      --		WHEN 6
      --		-- THEN 'Saturday'
      --		THEN 'Sabato'
      --		WHEN 7
      --		-- THEN 'Sunday'
      --		THEN 'Domenica'
      --		ELSE ''
      --	END ) ;
      set VAR_DAY_NAME = dayname(VAR_DATE);
      set VAR_QUARTER_NAME = trim(char(year(VAR_DATE))) concat 'Q' concat trim(char(quarter(VAR_DATE)));
      set VAR_WEEKEND =
      	(case VAR_DOW
 	       -- istruzioni se si usa DAYOFWEEK
 	       --WHEN 1
 	       --THEN 'Y'
 	       --WHEN 7
 	       --THEN 'Y'
      	   -- istruzioni se si usa DAYOFWEEK_ISO
      	   when 6 then 'S'
           when 7 then 'S'
           else 'N'
      	 end);
      -- stagioni secondo il calendario astronomico dell'emisfero boreale	
      set VAR_SEASON =
      	(case
      	   when VAR_MM < 3 or (VAR_MM = 3 and VAR_DD < 21)
           -- THEN 'Winter'
      	     then 'Inverno'
      	   when VAR_MM < 6 or (VAR_MM = 6 and VAR_DD < 21)
           -- THEN 'Spring'
      	     then 'Primavera'
      	   when VAR_MM < 9 or (VAR_MM = 9 and VAR_DD < 21)
           -- THEN 'Summer'
      	     then 'Estate'
      	   when VAR_MM < 12 or (VAR_MM = 12 and VAR_DD < 21)
           -- THEN 'Autumn'
      	     then 'Autunno'
      	   -- ELSE 'Winter'
      	   else 'Inverno'
      	 end);
      -- stagioni secondo il calendario meteorologico emisfero boreale
      -- primavera: 1/3-31/5
      -- estate: 1/6-31/8
      -- autunno: 1/9-30/11
      -- inverno: 1/12-28/2 (o 29/2)
      --set VAR_SEASON =
      --	(case
      --	   when VAR_MM <= 2
      --     -- THEN 'Winter'
      --	     then 'Inverno'
      --	   when VAR_MM <= 5
      --     -- THEN 'Spring'
      --	     then 'Primavera'
      --	   when VAR_MM <= 8
      --     -- THEN 'Summer'
      --	     then 'Estate'
      --	   when VAR_MM <= 11
      --     -- THEN 'Autumn'
      --	     then 'Autunno'
	  --       else
	  --	     then 'Inverno'
      --	 end);

      -- anno fiscale da ottobre a settembre
      --set VAR_FISCAL_QUARTER =
      --	( CASE
      --	WHEN VAR_MM < 4
      --	THEN 2
      --	WHEN VAR_MM < 7
      --	THEN 3
      --	WHEN VAR_MM < 10
      --	THEN 4
      --	ELSE 1
      --	END ) ;
      -- anno fiscale da aprile a marzo
      set VAR_FISCAL_QUARTER =
      	(case
      	   when VAR_MM < 4  then 4
      	   when VAR_MM < 7  then 1
      	   when VAR_MM < 10 then 2
      	   else 3
      	 end);
      -- anno fiscale da ottobre a settembre
      --set VAR_FISCAL_YEAR =
      --	( CASE
      --		WHEN VAR_MM < 10
      --		THEN YEAR ( VAR_DATE )
      --		ELSE YEAR ( VAR_DATE ) + 1
      --	END ) ;
      -- anno fiscale da aprile a marzo
      set VAR_FISCAL_YEAR =
      	(case
      	   when VAR_MM < 4 then year(VAR_DATE)
           else year(VAR_DATE) + 1
      	 end);
      set VAR_MONTH_NAME = monthname(VAR_DATE);
      set VAR_MONTH_ABRV =
        (case VAR_MM
           when 1
           -- then 'JAN'
             then 'GEN'
           when 2
             then 'FEB'
           when 3
             then 'MAR'
           when 4
             then 'APR'
           when 5
           -- then 'MAY'
             then 'MAG'
           when 6
           -- then 'JUN'
             then 'GIU'
           when 7
           -- then 'JUL'
             then 'LUG'
           when 8
           -- then 'AUG'
             then 'AGO'
           when 9
           -- then 'SEP'
             then 'SET'
           when 10
           -- then 'OCT'
             then 'OTT'
           when 11
             then 'NOV'
           when 12
           -- then 'DEC'
             then 'DIC'
           else ''
      	 end);
      set VAR_JULIAN = decimal(substring(char((year(VAR_DATE) * 1000 + dayofyear(VAR_DATE))), 1, 7));
      -- data ultimo giorno lavorativo settimana (venerdi')
      set VAR_WEEK_ENDING_DATE =
        (case VAR_DOW
           when 1 then VAR_DATE + 4 days
           when 2 then VAR_DATE + 3 days
           when 3 then VAR_DATE + 2 days
           when 4 then VAR_DATE + 1 days
           when 5 then VAR_DATE
           when 6 then VAR_DATE + 6 days
           when 7 then VAR_DATE + 5 days
           else null
      	 end);
      -- data ultimo giorno settimana (domenica)
      set VAR_WEEK_ENDING_SUN_DATE =
        (case VAR_DOW
           when 1 then VAR_DATE + 6 days
           when 2 then VAR_DATE + 5 days
           when 3 then VAR_DATE + 4 days
           when 4 then VAR_DATE + 3 days
           when 5 then VAR_DATE + 2 days
           when 6 then VAR_DATE + 1 days
           when 7 then VAR_DATE
           else null
      	 end);
      -- data del primo giorno della settimana (sabato)
      --set VAR_WEEK_STARTING_DATE = VAR_WEEK_ENDING_DATE - 6 DAYS;
      -- data del primo giorno della settimana (lunedi')
      set VAR_WEEK_STARTING_DATE = VAR_WEEK_ENDING_SUN_DATE - 6 days;
      set VAR_SAME_DAY_LAST_YEAR = VAR_DATE - 364 days;

      -- inserimento rek in tabella
      insert into Date_Conversion values
        (
         VAR_DATE,
         VAR_JDE_JULIAN_DATE,
         VAR_DATE_MDYY_DEC,
         VAR_DATE_MDYY_ZONED,
         VAR_DATE_MDYY_CHAR,
         VAR_DATE_YYMD_DEC,
         VAR_DATE_YYMD_ZONED,
         VAR_DATE_YYMD_CHAR,
         VAR_CC_CHAR,
         VAR_YY_CHAR,
         VAR_MM_CHAR,
         VAR_DD_CHAR,
         VAR_YEAR,
         VAR_DOW,
         VAR_DOY,
         VAR_WOY,
         VAR_QOY,
         VAR_CC,
         VAR_YY,
         VAR_YYYY,
         VAR_MM,
         VAR_DD,
         VAR_DAY_NAME,
         VAR_QUARTER_NAME,
         VAR_WEEKEND,
         VAR_SEASON,
         VAR_FISCAL_YEAR,
         VAR_FISCAL_QUARTER,
         VAR_MONTH_NAME,
         VAR_MONTH_ABRV,
         VAR_JULIAN,
         VAR_CYYMMDD_DEC,
         VAR_EXCEL_DATE,
         VAR_WEEK_STARTING_DATE,
         VAR_WEEK_ENDING_DATE,
         VAR_WEEK_ENDING_SUN_DATE,
         VAR_SAME_DAY_LAST_YEAR,
         VAR_CURRENT_DAY,
         VAR_CURRENT_WEEK,
         VAR_CURRENT_MONTH,
         VAR_CURRENT_QUARTER,
         VAR_CURRENT_YEAR,
         VAR_CURRENT_DAY_LAST_YEAR,
         VAR_CURRENT_WEEK_LAST_YEAR,
         VAR_CURRENT_MONTH_LAST_YEAR,
         VAR_CURRENT_QUARTER_LAST_YEAR,
         VAR_CURRENT_YEAR_LAST_YEAR
        );

      -- data per ciclo successivo
      set VAR_DATE = VAR_DATE + 1 day;
      -- test fine ciclo
      until VAR_DATE > '12/31/2099'		-- DATA FINALE
  end repeat ;
 END;

comment on procedure LOAD_DATE_CONVERSION_TABLE is 'Popolamento iniziale tabella conversione date';
label on procedure LOAD_DATE_CONVERSION_TABLE is 'Popolamento iniziale tabella conversione date';

-- procedura aggiornamento tabella
create or replace procedure UPDATE_DATE_CONVERSION_TABLE( )
  language sql
  specific UPDDATCNV

 BEGIN

   update Date_Conversion
     set DC_CURRENT_DAY = 'N'
     where DC_CURRENT_DAY = 'S';
   update Date_Conversion
     set DC_CURRENT_WEEK = 'N'
     where DC_CURRENT_WEEK = 'S';
   update Date_Conversion
     set DC_CURRENT_MONTH = 'N'
     where DC_CURRENT_MONTH = 'S';
   update Date_Conversion
     set DC_CURRENT_QUARTER = 'N'
     where DC_CURRENT_QUARTER = 'S';
   update Date_Conversion
     set DC_CURRENT_YEAR = 'N'
     where DC_CURRENT_YEAR = 'S';
   update Date_Conversion
     set DC_CURRENT_DAY_LAST_YEAR = 'N'
     where DC_CURRENT_DAY_LAST_YEAR = 'S';
   update Date_Conversion
     set DC_CURRENT_WEEK_LAST_YEAR = 'N'
     where DC_CURRENT_WEEK_LAST_YEAR = 'S';
   update Date_Conversion
     set DC_CURRENT_MONTH_LAST_YEAR = 'N'
     where DC_CURRENT_MONTH_LAST_YEAR = 'S';
   update Date_Conversion
     set DC_CURRENT_QUARTER_LAST_YEAR = 'N'
     where DC_CURRENT_QUARTER_LAST_YEAR = 'S';
   update Date_Conversion set DC_CURRENT_YEAR_LAST_YEAR = 'N' where DC_CURRENT_YEAR_LAST_YEAR = 'S';
   update Date_Conversion set DC_CURRENT_DAY = 'S' where DC_DATE = current date ;
   update Date_Conversion set DC_CURRENT_WEEK = 'S'
     where DC_DATE >= (select DC_WEEK_STARTING_DATE
                         from Date_Conversion
                         where DC_DATE = current date )
   	and DC_DATE <= (select DC_WEEK_ENDING_DATE
   	                  from Date_Conversion
   	                  where DC_DATE = current date );
   update Date_Conversion set DC_CURRENT_MONTH = 'S'
   	where DC_YEAR = year(current date ) and DC_MM = month(current date );
   update Date_Conversion set DC_CURRENT_QUARTER = 'S'
   	where DC_YEAR = year(current date ) and DC_QOY = quarter(current date );
   update Date_Conversion set DC_CURRENT_YEAR = 'S' where DC_YEAR = year(current date );
   update Date_Conversion set DC_CURRENT_DAY_LAST_YEAR = 'S' where DC_DATE = current date  - 364 days;
   update Date_Conversion set DC_CURRENT_WEEK_LAST_YEAR = 'S'
     where DC_DATE >= (select DC_WEEK_STARTING_DATE
                         from Date_Conversion
                         where DC_DATE = (current date  - 364 DAYS))
       and DC_DATE <= (select DC_WEEK_ENDING_DATE
                         from Date_Conversion where DC_DATE = (current date - 364 days));
   update Date_Conversion set DC_CURRENT_MONTH_LAST_YEAR = 'S'
   	where DC_YEAR = (year(current date) - 1) and DC_MM = month(current date);
   update Date_Conversion set DC_CURRENT_QUARTER_LAST_YEAR = 'S'
   	where DC_YEAR = (year(current date ) - 1) and DC_QOY = quarter(current date);
   update Date_Conversion set DC_CURRENT_YEAR_LAST_YEAR = 'S'
   	where DC_YEAR = (year(current date) - 1);
   	
 END;

comment on procedure UPDATE_DATE_CONVERSION_TABLE is 'Aggiornamento giornaliero tabella conversione date';
label on procedure UPDATE_DATE_CONVERSION_TABLE is 'Aggiornamento giornaliero tabella conversione date';

/*--- [4] info versione ---*/
call qcmdexc('CRTDTAARA DTAARA(*CURLIB/MK1VER) TYPE(*CHAR) LEN(50) VALUE(''2.0 - 29/05/2019 - (c) MarkOneTools'') TEXT(''Info versione'')');
call qcmdexc('OVRPRTF FILE(QPDSPDTA) TOFILE(QPDSPDTA) USRDTA(''Versione'')');
call qcmdexc('DSPDTAARA DTAARA(*CURLIB/MK1VER) OUTPUT(*PRINT)');
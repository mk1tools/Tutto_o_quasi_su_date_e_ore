/****************************/
/* TABELLA CONVERSIONE DATE */
/****************************/

/* cfr. istruzioni nello script MK1DATECNV.SQL */

set path = MK1DATECNV, SYSTEM PATH;

-- esecuzione aggiornamento giornaliero della tabella (schedulare ogni giorno)
CALL UPDATE_DATE_CONVERSION_TABLE;